from __future__ import print_function
import argparse
import numpy as np
import csv
import torch
import torch.nn as nn
import torch.optim as optim
from matplotlib import pyplot as plt
from torchvision import transforms
from torch.optim.lr_scheduler import StepLR
from torch.utils.data import DataLoader, Dataset
import pandas as pd
from pandas import read_csv
from torch.autograd import Variable


# clear dataset
def get_data(args):
    stock_data = read_csv("data/stock.csv")
    stock_data.drop('ts_code', axis=1, inplace=True)
    stock_data.drop('id', axis=1, inplace=True)
    stock_data.drop('pre_close', axis=1, inplace=True)
    stock_data.drop('trade_date', axis=1, inplace=True)

    close_max = stock_data['close'].max()
    close_min = stock_data['close'].min()
    df = stock_data.apply(lambda x: (x - min(x)) / (max(x) - min(x)))

    sequence = args.seq_len
    X = []
    Y = []
    for i in range(df.shape[0] - sequence):
        X.append(np.array(df.iloc[i:(i + sequence), 1:].values, dtype=np.float32))
        Y.append(np.array(df.iloc[(i + sequence) - 1, 0], dtype=np.float32))
    # print("train data  of item  0: \n", len(X))
    # print("train label of item  0: \n", len(Y))
    total_len = len(Y)

    train_x, train_y = X[:int(0.99 * total_len)], Y[:int(0.99 * total_len)]
    test_x, test_y = X[int(0.99 * total_len):], Y[int(0.99 * total_len):]
    train_loader = DataLoader(dataset=Mydataset(train_x, train_y, transform=transforms.ToTensor()),
                              batch_size=args.batch_size, shuffle=True)
    test_loader = DataLoader(dataset=Mydataset(test_x, test_y), batch_size=args.batch_size, shuffle=True)
    return close_max, close_min, train_loader, test_loader


class Mydataset(Dataset):
    def __init__(self, xx, yy, transform=None):
        self.x = xx
        self.y = yy
        self.tranform = transform

    def __getitem__(self, index):
        x1 = self.x[index]
        y1 = self.y[index]
        if self.tranform is not None:
            return self.tranform(x1), y1
        return x1, y1

    def __len__(self):
        return len(self.x)


class Lstm(nn.Module):

    def __init__(self, args):
        super(Lstm, self).__init__()
        # lstm的输入 #batch,seq_len, input_size
        self.hidden_size = args.hidden_size
        self.input_size = args.input_size
        self.num_layers = args.num_layers
        self.output_size = args.output_size
        self.seq_len = args.seq_len
        self.dropout = args.dropout
        self.batch_first = args.batch_first
        self.rnn = nn.LSTM(input_size=self.input_size, hidden_size=self.hidden_size, num_layers=self.num_layers,
                           batch_first=self.batch_first, dropout=self.dropout)
        self.linear = nn.Linear(self.hidden_size, self.output_size)

    def forward(self, x):
        if self.seq_len == 1:
            x = x.view(len(x), 1, -1)
        out, (hidden, cell) = self.rnn(x)  # x.shape : batch, seq_len, hidden_size , hn.shape and cn.shape : num_layes
        out = self.linear(hidden)
        return out


def train(args, model, train_loader, optimizer, device, epoch):
    loss_fun = nn.MSELoss()
    global train_loss
    train_loss = 0
    loss = 0
    for idx, (data, label) in enumerate(train_loader):
        data, label = data.to(device), label.to(device)
        if args.useGPU:
            data1 = data.squeeze(1).cuda()
            pred = model(Variable(data1).cuda())
            pred = pred[1, :, :]
            label = label.unsqueeze(1).cuda()
        else:
            data1 = data.squeeze(1)
            pred = model(Variable(data1))
            pred = pred[1, :, :]
            label = label.unsqueeze(1)
        loss = loss_fun(pred, label)
        train_loss += loss_fun(pred, label).item()
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        if idx % args.log_interval == 0:
            print('Train Epoch: {} [{}/{} ({:.0f}%) batch_size: {}]\tLoss: {:.6f}'.format(
                epoch, idx, len(train_loader), 100. * idx / len(train_loader), len(data), loss.item()))
            if args.dry_run:
                break
    train_loss /= len(train_loader)
    print("The final avarage train loss: {:.6f}".format(train_loss))
    train_loss = ('%.6f' % train_loss)
    torch.save({'state_dict': model.state_dict()}, args.save_file)


def test(args, model, close_max, close_min, test_loader, device):
    checkpoint = torch.load(args.save_file)
    model.load_state_dict(checkpoint['state_dict'])
    preds = []
    labels = []
    with torch.no_grad():
        for idx, (x, label) in enumerate(test_loader):
            x, label = x.to(device), label.to(device)
            if args.useGPU:
                x = x.squeeze(1).cuda()  # batch_size,seq_len,input_size
            else:
                x = x.squeeze(1)
            pred = model(x)
            list = pred.data.squeeze(1).tolist()
            preds.extend(list[-1])
            labels.extend(label.tolist())

    global absolute_error
    absolute_error = 0
    for i in range(len(preds)):
        print('prediction value: %.2f,  label value: %.2f' % (preds[i][0] * (close_max - close_min) + close_min,
                                                              labels[i] * (close_max - close_min) + close_min))
        absolute_error += abs((preds[i][0] * (close_max - close_min) + close_min) - (labels[i] * (close_max - close_min) + close_min))

    absolute_error /= len(preds)
    print('Test set: mean absolute_error: {:.4f}\n'.format( absolute_error))
    absolute_error = ('%.5f' % absolute_error)


# record data in a csv file
def collect_inform(inform):
    # Write files
    filename = 'data/result.csv'
    with open(filename, 'a+', newline='', encoding='utf-8-sig') as f:
        csv_write = csv.writer(f)
        csv_write.writerow(inform)

    # delete the duplicates
    data = pd.read_csv(filename)
    data.drop_duplicates(inplace=True)
    data.to_csv('data/result.csv', index=False)


def main():
    # Training settings
    parser = argparse.ArgumentParser(description='PyTorch LSTM Example')
    parser.add_argument('--epochs', type=int, default=100, metavar='N',
                        help='number of epochs to train (default: 14)')  # 14
    parser.add_argument('--lr', type=float, default=0.02, metavar='LR',
                        help='learning rate (default: 0.0001，0.001,0.01,0.2,0.03,0.04,0.02(best))')
    parser.add_argument('--save_file', default='model/stock.pkl')  # Model save location
    parser.add_argument('--num_layers', default=2, type=int,
                        help='num_layers (default: 2)')  # LSTM layers
    parser.add_argument('--input_size', default=7, type=int,
                        help='input_size (default: 7)')  # Enter the dimension of the feature (length of each word)
    parser.add_argument('--hidden_size', default=32, type=int,
                        help='hidden_size (default: 32)')  # Dimension of hidden layer (number of nodes)
    parser.add_argument('--seq_len', default=7, type=int,
                        help='seq_len (default: 4,5,6,7(best),8,9,10)')
    parser.add_argument('--useGPU', default=False, type=bool,
                        help='useGPU (default: False)')  # Whether use GPU
    parser.add_argument('--batch_first', default=True, type=bool,
                        help='batch_first (default: True)')
    parser.add_argument('--dropout', default=0, type=float,
                        help='dropout (default: 0.1)')
    parser.add_argument('--batch_size', default=64, type=int)
    parser.add_argument('--gamma', type=float, default=0.7, metavar='M',
                        help='Learning rate step gamma (default: 0.7)')
    parser.add_argument('--seed', type=int, default=1, metavar='S',
                        help='random seed (default: 1)')
    parser.add_argument('--no-cuda', action='store_true', default=False,
                        help='disables CUDA training')
    parser.add_argument('--log-interval', type=int, default=1, metavar='N',
                        help='how many batches to wait before logging training status')
    parser.add_argument('--dry-run', action='store_true', default=False,
                        help='quickly check a single pass')
    parser.add_argument('--output_size', type=int, default=1,
                        help='output_size (default: 1)')

    args = parser.parse_args()
    torch.manual_seed(args.seed)
    # 固定随机
    device = torch.device(f"cuda:{args.gpu}" if torch.cuda.is_available() and args.useGPU else "cpu")
    model = Lstm(args)

    close_max, close_min, train_loader, test_loader = get_data(args)
    # Adadelta, Adam
    optimizer = optim.Adam(model.parameters(), lr=args.lr)
    scheduler = StepLR(optimizer, step_size=1, gamma=args.gamma)

    for epoch in range(1, args.epochs + 1):
        train(args, model, train_loader, optimizer, device, epoch)
        test(args, model,  close_max, close_min, test_loader, device)
        scheduler.step()
        inform = ["Adam", "StepLR:1", args.seq_len, args.lr, epoch, train_loss, absolute_error]
        collect_inform(inform)


# Print relationship charts
def chart():
    data = pd.read_csv("data/result.csv")
    data_1 = data.loc[data['learning_rate'] == 0.02]
    data_1 = data_1.loc[data['sequence_length'] == 7]
    data_1 = data_1.loc[data['optimizer'].str.contains("Adam")]
    data_1 = data_1.loc[:, ['optimizer', 'times', 'train_loss', 'mean_absolute_error']]
    data_1.reset_index(drop=True, inplace=True)
    data_1['mean_absolute_error'].plot(label="mean absolute error")
    plt.xlabel('Times')
    plt.ylabel('mean absolute error')
    plt.legend()
    plt.show()

    data_2 = data.loc[data['times'] == 50]
    data_2 = data_2.loc[data['sequence_length'] == 7]
    data_2 = data_2.loc[data['optimizer'].str.contains("Adam")]
    x_1 = data_2.loc[:, ['learning_rate']]
    y_1 = data_2.loc[:, ["mean_absolute_error"]]
    print(x_1, y_1)
    plt.scatter(x_1, y_1)
    plt.show()

    data_3 = data.loc[data['times'] == 50]
    data_3 = data_3.loc[data['sequence_length'] == 7]
    data_3 = data_3.loc[data['optimizer'].str.contains("Adadelta")]
    x_2 = data_3.loc[:, ['learning_rate']]
    y_2 = data_3.loc[:, ["mean_absolute_error"]]
    print(x_2, y_2)
    plt.scatter(x_2, y_2)
    plt.show()

    data_4 = data.loc[data['learning_rate'] == 1]
    data_4 = data_4.loc[data['sequence_length'] == 7]
    data_4 = data_4.loc[data['optimizer'].str.contains("Adam")]
    data_4 = data_4.loc[:, ['optimizer', 'times', 'train_loss', 'mean_absolute_error']]
    data_4.reset_index(drop=True, inplace=True)
    data_4['train_loss'].plot(label="mean absolute error")
    plt.xlabel('Times')
    plt.ylabel('mean absolute error')
    plt.legend()
    plt.show()


if __name__ == '__main__':
    main()
    # chart()
